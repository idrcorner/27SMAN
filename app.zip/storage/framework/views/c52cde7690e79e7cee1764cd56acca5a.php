

<?php $__env->startSection('title'); ?>
   Video: <?php echo e($video->judul); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Video :  <?php echo e($video->judul); ?></h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>    
             <li><a href="<?php echo e(route('listvideo')); ?>">Daftar Video</a></li>             
             <li class="active"><?php echo e($video->judul); ?></li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
          
               <div class="col-md-8">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-single">
                   <div class="row">
                     <div class="col-md-12">
                       <article class="mu-blog-single-item text-justify img-thumbnail" style="padding:20px">
                        
                        <iframe width="100%" height="380" src="https://www.youtube.com/embed/<?php echo e($video->deskripsi); ?>" title=" <?php echo e($video->judul); ?>" frameborder="0" ></iframe>
                     
                        
                       </article>
                     </div>                                   
                   </div>
                 </div>
               
             
               </div>

            <div class="col-md-4 ">
                <div class="mu-single-sidebar">
                    <h3> Video Lainnya</h3><br/>
               <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($video->id!=$vid->id): ?>
                    <div class=" text-center img-thumbnail ">
                        <iframe width="100%" height="180" src="https://www.youtube.com/embed/<?php echo e($vid->deskripsi); ?>" title=" <?php echo e($vid->judul); ?>" frameborder="0" ></iframe>
                     
                      
                       <a href="<?php echo e(route('detailvideo',$vid->slug)); ?>"> <strong class="text-center"><small> <?php echo e($vid->judul); ?></small></strong></a>
                       
                       </div>
                    <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
          
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/detailvideo.blade.php ENDPATH**/ ?>