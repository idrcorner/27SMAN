

<?php $__env->startSection('title'); ?>
    <?php echo e($blog->judul); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold"><?php echo e($blog->judul); ?></h2>
                    <h5 class="text-white op-7 mb-2"><?php echo e($blog->subjudul); ?> </h5>
                </div>
                <div class="ml-md-auto py-2 py-md-0">
                    
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row mt--2">
            <div class="col-md-12">
                <div class="card full-height">
                    <div class="card-body">
                        <i class="fas fa-calendar-alt mr-1 text-success" ></i> <?php echo e(date('d F Y', strtotime($blog->tgl_publis))); ?>

                        |
                         <i class="  fas fa-eye text-primary mr-1"></i> <?php echo e($blog->view); ?>

                         |
                          <i class="fas fa-user-astronaut text-warning mr-1"></i>  <?php echo e(getUsername($blog->user_id)); ?>

                        <br>
                        <br>
                        <br>
                     <center>
                        <img src="<?php echo e(url(Storage::url($blog->cover))); ?>" alt="cover" width="50%" style="border-radius: 10px">
                     </center>
                     <br>
                     <br>
                     <?php echo $blog->konten; ?>


                     <br>
                     <br>
                     <a class="btn btn-primary" href="<?php echo e(route('blog.index')); ?>">Kembali</a>

                    </div>
                </div>
            </div>
           
        </div>
      
    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/admin/blog/show.blade.php ENDPATH**/ ?>