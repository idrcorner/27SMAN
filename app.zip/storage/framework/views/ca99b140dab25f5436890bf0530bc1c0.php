

<?php $__env->startSection('title'); ?>
    <?php echo e($tentang->judul); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2><?php echo e($tentang->judul); ?></h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active"><?php echo e($tentang->judul); ?></li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-9">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-single">
                   <div class="row">
                     <div class="col-md-12">
                       <article class="mu-blog-single-item text-justify" style="padding:20px">
                        
                        <?php echo $tentang->konten; ?>

                        
                       </article>
                     </div>                                   
                   </div>
                 </div>
               
             
               </div>
               <div class="col-md-3">
                 <!-- start sidebar -->
                 <aside class="mu-sidebar">
                   <!-- start single sidebar -->
                   <div class="mu-single-sidebar">
                     <h3>Tentang Kami</h3>
                     <ul class="mu-sidebar-catg">
                        <?php $__currentLoopData = $tentangkamis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tentang->id!=$tk->id): ?>
                               <li><a href="<?php echo e(route('tentangkamidetail',$tk->slug)); ?>"><?php echo e($tk->judul); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                       
                     </ul>
                   </div>
                   <!-- end single sidebar -->
                   <!-- start single sidebar -->
                   <div class="mu-single-sidebar text-center">
                     <h3>Kepala Sekolah</h3>
                     <div class="mu-sidebar-popular-courses text-center">
                        <img src="<?php echo e(url(Storage::url($kepsek->foto))); ?>" width="100%" alt="Foto Kepala Sekolah" class="img-thumbnail" style="margin-bottom:10px">
                        
                        <p style="margin-bottom:-5px"><strong><?php echo e($kepsek->nama); ?></strong></p>
                        <small  >NIP:  <?php echo e($kepsek->nip); ?> </small>
                     </div>
                   </div>
                 
                 
                   <!-- end single sidebar -->
                 </aside>
                 <!-- / end sidebar -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/detailtentang.blade.php ENDPATH**/ ?>