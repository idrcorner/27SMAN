

<?php $__env->startSection('title'); ?>
   Guru dan Tata Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <style>
      .guru{
        font-size: 13px !important;
        border-radius: 10px;
    }

    .cardguru{
        margin-bottom:20px;
      
        
    }
    .jkLaki{
        background-color: rgba(200, 194, 245, 0.952);
        /* border:1px solid rgb(105, 105, 247); */
        border-radius: 10px;
    }
    .jkPr{
        background-color: rgba(245, 179, 182, 0.509);
        /* border:1px solid pink; */
        border-radius: 10px;
    }
.judulan{
    font-size: 9px;
    /* background: #9d8484; */
    /* margin-bottom: -3px !important; */
    font-weight: 600;
    color: rgb(0, 0, 0)
 
}
.isian{
    font-size: 12px;
    /* background: #07e28e; */
    margin-bottom: 1px !important;
}
    
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Guru dan Tata Usaha</h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active">Guru dan Tata Usaha</li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-9">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-single">
                   <div class="row">
                     <div class="col-md-12">
                       <article class="mu-blog-single-item " style="padding:20px">
                        
                    <?php $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div  class="card mb-6 col-md-6" >
                        <div class=" cardguru <?php echo e($guru->jk==0? ' jkPr':' jkLaki'); ?>"   style="padding: 5px 15px 5px 15px ">
                            <div class="row  "  style="padding: 5px 5px 5px -10px">
                              <div class="col-md-4" style="padding:5px !important">
                                <img src="<?php echo e(url(Storage::url($guru->foto))); ?>" width="100%" class="card-img-top" alt="..." style=" border-radius: 10px">
                              </div>
                              <div class="col-md-8 ket" style="padding:5px 15px 15px 15px !important">
                                   
                                <div class="judulan">Nama:</div>
                                <div class="isian"> <?php echo e($guru->nama); ?> </div>
                                <div class="judulan">Tempat, Tanggal Lahir:</div>
                                <div class="isian"><?php echo e($guru->tmpt_lahir); ?>, <?php echo e(date('d F Y', strtotime($guru->tgl_lahir))); ?> </div>
                                <div class="judulan">Jenis Kelamin:</div>
                                <div class="isian"><?php echo e($guru->jk==1? "Laki-laki": "Perempuan"); ?></div>
                                <div class="judulan">Jabatan/Tugas:</div>
                                <div class="isian"><?php echo e($guru->jabatan); ?></div>
                             
                               
                              </div>
                            </div>
                          </div>
                        
                    </div>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                       </article>
                     </div>                                   
                   </div>
                 </div>
               
             
               </div>
               <div class="col-md-3">
                 <!-- start sidebar -->
                 <aside class="mu-sidebar">
                   <!-- start single sidebar -->
              
                   <!-- end single sidebar -->
                   <!-- start single sidebar -->
                   <div class="mu-single-sidebar text-center">
                     <h3>Kepala Sekolah</h3>
                     <div class="mu-sidebar-popular-courses text-center">
                        <img src="<?php echo e(url(Storage::url($kepsek->foto))); ?>" width="100%" alt="Foto Kepala Sekolah" class="img-thumbnail" style="margin-bottom:10px">
                        
                        <p style="margin-bottom:-5px"><strong><?php echo e($kepsek->nama); ?></strong></p>
                        <small  >NIP:  <?php echo e($kepsek->nip); ?> </small>
                     </div>
                   </div>

                   <div class="mu-single-sidebar">
                    <h3>Tentang Kami</h3>
                    <ul class="mu-sidebar-catg">
                       <?php $__currentLoopData = $tentangkamis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                              <li><a href="<?php echo e(route('tentangkamidetail',$tk->slug)); ?>"><?php echo e($tk->judul); ?></a></li>
                          
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                      
                    </ul>
                  </div>
                 
                 
                   <!-- end single sidebar -->
                 </aside>
                 <!-- / end sidebar -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/listguru.blade.php ENDPATH**/ ?>