WEB HOME
 <?php /**PATH C:\laragon\www\sman27\resources\views/welcome.blade.php ENDPATH**/ ?>