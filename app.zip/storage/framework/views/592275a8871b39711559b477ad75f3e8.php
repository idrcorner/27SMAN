

<?php $__env->startSection('title'); ?>
   Tambah Quote
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="panel-header bg-primary-gradient">
            <div class="page-inner py-5">
                <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                    <div>
                        <h2 class="text-white pb-2 fw-bold">Tambah Quote</h2>
                        
                    </div>
                    <div class="ml-md-auto py-2 py-md-0">                  
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="page-inner mt--5">
            <div class="row mt--2">
                <div class="col-md-12">
                    <div class="card full-height">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                <form action="<?php echo e(route('quote.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                  
                                        <div class="form-group">
                                            <label for="quote">Quote </label> <?php $__errorArgs = ['quote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <textarea  name="quote" class="form-control" id="quote" placeholder="  Quote" required><?php echo e(old('quote')); ?></textarea>                      
                                        </div>
                                        <div class="form-group">
                                            <label for="oleh">Oleh </label> <?php $__errorArgs = ['oleh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> </span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <input type="text" name="oleh" class="form-control" value="<?php echo e(old('oleh')); ?>" id="oleh" placeholder="  Oleh" required>                      
                                        </div>
                                        
                            
                                         
                                            <hr>
                                    <input type="submit" value="SIMPAN" class="btn btn-primary">
                                    <a href="<?php echo e(route('quote.index')); ?>" class="btn btn-link" >Batal</a>
                                   
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
          
        </div>
    </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/admin/quote/create.blade.php ENDPATH**/ ?>