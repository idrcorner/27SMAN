
<?php $__env->startSection('title'); ?>
    Daftar Informasi Sekolah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Informasi Sekolah</h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active">Informasi Sekolah</li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-12">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-archive">
                   <div class="row">
                    <?php
                        $x=0;
                    ?>
                    <?php $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $x++;
                        ?>
                    <div class="col-md-3 col-sm-3">
                            <article class="mu-blog-single-item img-thumbnail">
                           
                              <a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>"><img src="<?php echo e(url(Storage::url($informasi->cover))); ?>" alt="img" width="100%"></a>
                                              
                            
                           <div style="padding:10px">
                           
                              
                              <h4 style="margin-top:10px "><a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>"><strong><?php echo e($informasi->judul); ?></strong></a></h4>
                                
                            <div class="mu-blog-meta">
                              <small>
                                 
                                  <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($informasi->tgl_publis))); ?></span>
                                  <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($informasi->view); ?></span>
                                </small>
                            </div>
                            <div class="mu-blog-description text-justify">
                              <p><?php echo e($informasi->subjudul); ?></p>
                            
                            </div>
                           </div>
                          </article> 
                        
                      </div>   

                      <?php if($x==4): ?>
                          <?php
                              $x=0;
                          ?>
                          </div>
                          <div class="row">
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                     
                 </div>
                 <!-- end course content container -->
                 <!-- start course pagination -->
                 <div class="mu-pagination">
                   <?php echo e($informasis->links()); ?>

                 </div>
                 <!-- end course pagination -->
               </div>
               
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/listinformasi.blade.php ENDPATH**/ ?>