<!-- Sidebar -->
<div class="sidebar sidebar-style-2">			
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
             
            <ul class="nav nav-primary">
                <li class="nav-item <?php echo e($menu=='dashboard'? ' active ':''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="collapsed" aria-expanded="false">
                        <i class="icon-speedometer"></i>
                        <p>Dashboard</p>                       
                    </a>            
                </li>
             <?php if(auth()->user()->role=='admin'): ?>
             <li class="nav-item  <?php echo e($menu=='informasi'? ' active ':''); ?>">
                <a href="<?php echo e(route('informasi.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-book-open"></i>
                    <p>Informasi Sekolah</p>                       
                </a>            
            </li>
            <li class="nav-item  <?php echo e($menu=='profil'? ' active ':''); ?> ">
                <a href="<?php echo e(route('profil.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-directions"></i>
                    <p>Tentang Kami</p>                       
                </a>            
            </li>
            <li class="nav-item <?php echo e($menu=='guru'? ' active ':''); ?> ">
                <a href="<?php echo e(route('guru.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-people"></i>
                    <p>Guru dan TU</p>                       
                </a>            
            </li>
            <li class="nav-item   <?php echo e($menu=='prestasi'? ' active ':''); ?> ">
                <a href="<?php echo e(route('prestasi.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-trophy"></i>
                    <p>Prestasi</p>                       
                </a>            
            </li>
            <li class="nav-item  <?php echo e($menuparent=='galeri'? ' active ':''); ?>">
            <a data-toggle="collapse" href="#dashboard" class="collapsed" aria-expanded="false">
                <i class="icon-picture"></i>
                <p>Galeri</p>
                <span class="caret"></span>
            </a>
            <div class="collapse  <?php echo e($menuparent=='galeri'? ' show ':''); ?>" id="dashboard">
                <ul class="nav nav-collapse">
                    <li   class=" <?php echo e($menu=='album'? 'active   ':''); ?> ">
                        <a href="<?php echo e(route('album.index')); ?>"  aria-expanded="false">
                            <i class="icon-picture"></i>
                            <p>Album Foto</p>                       
                        </a>            
                    </li>
                   
                    <li    class=" <?php echo e($menu=='video'? ' active ':''); ?> ">
                        <a href="<?php echo e(route('video.index')); ?>"  aria-expanded="false">
                            <i class=" icon-camrecorder"></i>
                            <p>Video</p>                       
                        </a>            
                    </li>
                </ul>
            </div>
         </li>
            
            <li class="nav-item  <?php echo e($menu=='slider'? ' active ':''); ?> ">
                <a href="<?php echo e(route('slider.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-control-end"></i>
                    <p>Slider</p>                       
                </a>            
            </li>
            <li class="nav-item  <?php echo e($menu=='quote'? ' active ':''); ?> ">
                <a href="<?php echo e(route('quote.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-diamond"></i>
                    <p>Quote</p>                       
                </a>            
            </li>
            <li class="nav-item  <?php echo e($menu=='user'? ' active ':''); ?> ">
                <a href="<?php echo e(route('user.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-people"></i>
                    <p>User</p>                       
                </a>            
            </li>
        <hr>
        <li class="nav-item  <?php echo e($menu=='blog'? ' active ':''); ?> ">
            <a href="<?php echo e(route('blogadmin.index')); ?>" class="collapsed" aria-expanded="false">
                <i class="icon-book-open"></i>
                <p>Blog Guru</p>                       
            </a>            
        </li>
        <li class="nav-item  <?php echo e($menu=='kepsek'? ' active ':''); ?> ">
            <a href="<?php echo e(route('kepsek.edit')); ?>" class="collapsed" aria-expanded="false">
                <i class="icon-user"></i>
                <p>Kepala Sekolah</p>                       
            </a>            
        </li>
        <li class="nav-item  <?php echo e($menu=='kontak'? ' active ':''); ?> ">
            <a href="<?php echo e(route('kontak.index')); ?>" class="collapsed" aria-expanded="false">
                <i class="icon-direction"></i>
                <p>Kontak</p>                       
            </a>            
        </li>
             <?php endif; ?>

             <?php if(auth()->user()->role=='blogguru'): ?>
             <li class="nav-item  <?php echo e($menu=='blog'? ' active ':''); ?>">
                <a href="<?php echo e(route('blog.index')); ?>" class="collapsed" aria-expanded="false">
                    <i class="icon-book-open"></i>
                    <p>Artikel Anda</p>                       
                </a>            
            </li>
            <?php endif; ?>

            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->
<?php /**PATH C:\laragon\www\sman27\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>