

<?php $__env->startSection('title'); ?>
    <?php echo e(appname()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-slider">
   <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="mu-slider-single">
    <div class="mu-slider-img">
      <figure>
        <img src="<?php echo e(url(Storage::url($slider->cover))); ?>" alt="img-slider">
      </figure>
    </div>
    <div class="mu-slider-content">
      <h4><?php echo e($slider->judul); ?></h4>
      <span></span>
      
      <p><?php echo e($slider->deskripsi); ?></p>
      
    </div>
  </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
 
   
  </section>
  <!-- End Slider -->
  <!-- Start service  -->
  <section id="mu-service">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-service-area">
            <!-- Start single service -->
            <div class="mu-service-single">
              <a href="<?php echo e(route('listprofil')); ?>" style="color:#DFD0B8">
              <span class="fas fa-school"></span>
              <h3>Profil Sekolah</h3>
              </a>
            </div>
            <!-- Start single service -->
            <!-- Start single service -->
           
              <div class="mu-service-single">
                <a href="<?php echo e(route('listguru')); ?>">
                <span class="fa fa-users"></span>
                <h3>Guru dan Tata Usaha</h3>
              </a>
              </div>
          
            <!-- Start single service -->
            <!-- Start single service -->
            <div class="mu-service-single">
              <a href="<?php echo e(route('listprestasi')); ?>"  style="color:#DFD0B8">
              <span class="fas fa-trophy"></span>
              <h3>Prestasi</h3>
              </a>
            </div>
            <!-- Start single service -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End service  -->

  <!-- Start about us -->
  <section id="mu-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-about-us-area">           
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="mu-about-us-left">
                  <!-- Start Title -->
                  <div class="mu-title">
                    <h3 class="text-bold text-left mb-5"><strong>Sambutan Kepala Sekolah</strong></h3>              
                  </div>
                  <br>
                  <br>
                  <br>
              <div class="text-justify">
                
                <?php echo \Illuminate\Support\Str::limit($kepsek->katasambutan , 800); ?>

              </div>
                <a  href="<?php echo e(route('katasambutan')); ?>"class="btn btn-sm btn-primary">Baca Selengkapnya</a>
               </p>
             </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mu-about-us-right">                            
               
                  <img src="<?php echo e(url(Storage::url($kepsek->foto))); ?>"  width="100%" alt="img" style="border-radius: 5px" class="img-thumbnail">
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 
  <section id="mu-latest-courses">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-latest-courses-area">
            <!-- Start Title -->
            <div class="mu-title">
              <h2>Informasi Sekolah  </h2>
              
            </div>
            <!-- End Title -->
            <!-- Start latest course content -->
            <div id="mu-latest-course-slide" class="mu-latest-courses-content">
              <?php $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-4 col-xs-12">
                <div class="mu-latest-course-single" style="border-radius:5px">
                  <div  >
                    <a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>">
                      <img src="<?php echo e(url(Storage::url($informasi->cover))); ?>" width="100% "alt="img" style="border-radius:5px 5px 0px 0px">
                    </a>
      
                  </div>
                  
                  <div style="padding: 10px" class="text-center">
                   <small>
                    <span class="text-primary " style="margin-right:15px"><i class="fa fa-user  " style="margin-right:5px"> </i>Oleh. <?php echo e(getusername($informasi->user_id)); ?></span> 
                    <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($informasi->tgl_publis))); ?></span>
                    <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($informasi->view); ?></span>
                  </small>
                  </div>
                
                  <div class="mu-latest-course-single-content">
                    <h4>  <a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>"><strong><?php echo e($informasi->judul); ?></strong></a></h4>
                    <p><?php echo e($informasi->subjudul); ?></p>
                    <div class="mu-latest-course-single-contbottom">
                     <small> <a class="  text-primary" href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>">Baca Selengkapnya</a></small>
                     
                    </div>
                  </div>
                </div>
              </div>
            
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </div>
           
            <!-- End latest course content -->
          </div>
        </div>
       
      </div>
    </div>
   
  </section>


  <section id="mu-from-blog">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-from-blog-area">
            <!-- start title -->
           
            <!-- end title -->  
            <!-- start from blog content   -->
            <div class="mu-from-blog-content">
              <div class="row">
               
                <div class="col-md-8" >
                  
                      <h2>Artikel</h2>
                    <br>
                    <br>
                
                  <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                  <div class="card mb-3 img-thumbnail" style="margin-bottom:20px">
                    <div class="row no-gutters">
                      <div class="col-md-4">
                        <a href="<?php echo e(route('detailblog',$arti->slug)); ?>">  <img src="<?php echo e(url(Storage::url($arti->cover))); ?>" width="100%" class="card-img" alt="..." style="border-radius: 5px">
                        </a>
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                         
                          <a href="<?php echo e(route('detailblog',$arti->slug)); ?>"> <h4 class="card-title"><strong><?php echo e($arti->judul); ?></strong></h4></a>
                          <p class="card-text"><?php echo e($arti->subjudul); ?>.</p>
                          <p class="card-text"><small class="text-muted">

                            <div style=" " >
                              <small>
                               <span class="text-primary " style="margin-right:15px"><i class="fa fa-user  " style="margin-right:5px"> </i>Oleh. <?php echo e(getusername($arti->user_id)); ?></span> 
                               <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($arti->tgl_publis))); ?></span>
                               <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($arti->view); ?></span>
                             </small>
                             </div>
                          
                          </small></p>
                        </div>
                      </div>
                    </div>
                  </div> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4">
                  
                    <h2>Video</h2>
                   <br>
                   <br>
                   <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="card text-center img-thumbnail">
                        <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo e($video->deskripsi); ?>" title=" <?php echo e($video->judul); ?>" frameborder="0" ></iframe>
                       <strong class="text-center"> <?php echo e($video->judul); ?></strong>
                       
                       
                       </div>
                       <br/>
                       <br/>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
               
               
               
              </div>
            </div>     
            <!-- end from blog content   -->   
          </div>
        </div>
      </div>
    </div>
  </section>
 
 
  <section id="mu-testimonial">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-testimonial-area">
            <div id="mu-testimonial-slide" class="mu-testimonial-content">
             <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="mu-testimonial-item">
              <div class="mu-testimonial-quote">
                <blockquote>
                  <p><?php echo e($quote->quote); ?>.</p>
                </blockquote>
              </div>
               
              <div class="mu-testimonial-info">
                <h4><?php echo e($quote->oleh); ?></h4>
               
              </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End testimonial -->

  <!-- Start from blog -->

  <!-- End from blog -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/index.blade.php ENDPATH**/ ?>