
<?php $__env->startSection('title'); ?>
    Daftar Video
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Daftar Video</h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active">Video</li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-12">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-archive">
                   <div class="row">
                    <?php
                        $x=0;
                    ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $x++;
                        ?>
                    <div class="col-md-4 col-sm-4">
                     
                        <div class="card text-center ">
                         <iframe width="100%" height="180" src="https://www.youtube.com/embed/<?php echo e($video->deskripsi); ?>" title=" <?php echo e($video->judul); ?>" frameborder="0" ></iframe>
                      
                       
                        <a href="<?php echo e(route('detailvideo',$video->slug)); ?>">  <strong class="text-center"> <?php echo e($video->judul); ?></strong></a>
                           <hr>
                        </div>
                   
                    
                    </div>   

                      <?php if($x==3): ?>
                          <?php
                              $x=0;
                          ?>
                          </div>
                          <div class="row">
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                     
                 </div>
                 <!-- end course content container -->
                 <!-- start course pagination -->
                 <div class="mu-pagination">
                   <?php echo e($videos->links()); ?>

                 </div>
                 <!-- end course pagination -->
               </div>
               
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/listvideo.blade.php ENDPATH**/ ?>