
<?php $__env->startSection('title'); ?>
    Daftar Prestasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Prestasi</h2>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active">Prestasi</li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-12">
                 <!-- start course content container -->
                 <div class="mu-course-container mu-blog-archive">
                   <div class="row">
                    <?php
                        $x=0;
                    ?>
                    <?php $__currentLoopData = $prestasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $x++;
                        ?>
                    <div class="col-md-3 col-sm-3">
                            <article class="mu-blog-single-item">
                            <figure class="mu-blog-single-img">
                              <a href="<?php echo e(route('detailprestasi',$prestasi->slug)); ?>"><img src="<?php echo e(url(Storage::url($prestasi->cover))); ?>" alt="img" class="img-thumbnail"></a>
                              <figcaption class="mu-blog-caption">
                                <h4><a href="<?php echo e(route('detailprestasi',$prestasi->slug)); ?>"><strong><?php echo e($prestasi->judul); ?></strong></a></h4>
                              </figcaption>                      
                            </figure>
                            <div class="mu-blog-meta">
                              <small>
                                 
                                  <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($prestasi->created_at))); ?></span>
                                  <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($prestasi->view); ?></span>
                                </small>
                            </div>
                            <div class="mu-blog-description text-justify">
                              
                            
                            </div>
                          </article> 
                        
                      </div>   

                      <?php if($x==4): ?>
                          <?php
                              $x=0;
                          ?>
                          </div>
                          <div class="row">
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                     
                 </div>
                 <!-- end course content container -->
                 <!-- start course pagination -->
                 <div class="mu-pagination">
                   <?php echo e($prestasis->links()); ?>

                 </div>
                 <!-- end course pagination -->
               </div>
               
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/listprestasi.blade.php ENDPATH**/ ?>