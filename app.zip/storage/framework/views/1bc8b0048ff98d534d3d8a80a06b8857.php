

<?php $__env->startSection('title'); ?>
    <?php echo e(appname()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Dashboard</h2>
                    <h5 class="text-white op-7 mb-2">Selamat Datang, <?php echo e(auth()->user()->name); ?></h5>
                </div>
                <div class="ml-md-auto py-2 py-md-0">
                   
                    <?php if(auth()->user()->role=='admin'): ?>
                    <a href="<?php echo e(route('album.create')); ?>" class="btn btn-white btn-border btn-round mr-2">Tambah Album Foto</a>
                    <a href="<?php echo e(route('informasi.create')); ?>" class="btn btn-secondary btn-round">Tambah Informasi Sekolah</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-white btn-border btn-round mr-2">Tambah Artikel</a>
                   
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row mt--2">
            <div class="col-md-12">
                <div class="card full-height">
                    <div class="card-body">
                        <?php if(isset($quote)): ?>
                        <div class="card-title">Quotes Of The Day</div>
                        <div class="card-category">
                            "<?php echo e($quote->quote); ?>"
                            
                            -<strong><?php echo e($quote->oleh); ?></strong>-
                        </div>
                        <?php endif; ?>
                       
                      
                    </div>
                </div>
            </div>
           
        </div>
      
    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>