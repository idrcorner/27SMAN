

<?php $__env->startSection('title'); ?>
    Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="panel-header bg-primary-gradient">
            <div class="page-inner py-5">
                <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                    <div>
                        <h2 class="text-white pb-2 fw-bold">Slider</h2>
                        
                    </div>
                    <div class="ml-md-auto py-2 py-md-0">                  
                        <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-secondary btn-round">Tambah Slider</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-inner mt--5">
            <div class="row mt--2">
                <div class="col-md-12">
                    <div class="card full-height">
                        <div class="card-body">
                           <table class="table table-bordered table-hovered" id='iniTabel'>
                               <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Slider</th>
                                   
                                    <th>Action</th>
                                </tr>
                               </thead>
                               <tbody>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td>
                               
                                        <img src="<?php echo e(url(Storage::url($inf->cover))); ?>" alt="cover" width="100%" style="border-radius: 5px" >
                                        <br>
                                        <strong style="font-size: 20px" >  <?php echo e($inf->judul); ?></strong> 
                                        <br>
                                  <?php echo e($inf->deskripsi); ?>

                               <br>
                               <br>
                               <br>
                                    </td>
                                  
                                   
                               <td>
                                <a href="<?php echo e(route('slider.edit',$inf->id)); ?>"> <i class=" fas fa-pen text-warning mr-2" title="Ubah"></i></a>
                                        <i  onclick="alertdelete('<?php echo e($inf->judul); ?>','<?php echo e($inf->id); ?>')"
                                            role="button" class="fas fa-trash-alt text-danger cursor-pointer" title="Hapus"></i>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                        </div>
                    </div>
                </div>
               
            </div>
          
        </div>
    </div>

    <form id="deleteform" action="<?php echo e(route('slider.delete')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input id="idPrestasi" type="hidden" name="id" value="">
     
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
 

<script>
    $(document).ready(function() {

        // $('#sideB').addClass('sidebar_minimize');

        var table=  $('#iniTabel').DataTable({
            ordering: false,
            pageLength: 100
         });
       
         table.destroy()
        $('#iniTabel').DataTable({
                ordering: false,
                pageLength: 100,
                info: false
            });
		}); 
        
        function alertdelete(judul, id) {
        swal({
            title: 'Anda yakin?'
            , text: "Menghapus Prestasi : " + judul
            , icon: 'warning'
            , buttons: {
                confirm: {
                    text: 'Ya, Hapus'
                    , className: 'btn btn-primary'
                }
                , cancel: {
                    visible: true
                    , className: 'btn btn-danger'
                }
            }
        }).then((result) => {
            if (result) {
                document.getElementById("idPrestasi").value=id
                document.getElementById("deleteform").submit();  
            } 
        });
    }
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>