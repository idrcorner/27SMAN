
<?php $__env->startSection('title'); ?>
   Pencarian : <?php echo e($cari); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2>Pencarian : <?php echo e($cari); ?></h2>
            <p class="  text-center" style="color:white">Ditemukan <?php echo e($total); ?> item</p>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li class="active">Pencarian</li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End breadcrumb -->
  <section id="mu-course-content">
  
    <div class="container">
        <h3><em style="color:blue">Pencarian : "<?php echo e($cari); ?>", ditemukan <?php echo e($total); ?> item</em></h3> <br/><br/>
      <div class="row">
     
       
        <div class="col-md-12">
          <div class="mu-course-content-area">
             <div class="row">
               <div class="col-md-6">
                <?php $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               
            <div class="col-md-12">
                <div class="card mb-3 " style="margin-bottom:10px;border-bottom:1px solid rgb(214, 211, 211);" >
                    <div class="row no-gutters">
                      <div class="col-md-4">
                        <a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>">
                        <img src="<?php echo e(url(Storage::url($informasi->cover))); ?>" class="card-img" width="100%" alt="...">
                      </a>
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                            <a href="<?php echo e(route('detailinformasi',$informasi->slug)); ?>">
                                <h4 class="card-title"><strong><?php echo e($informasi->judul); ?></strong></h4>
                            </a>
                          <p class="card-text text-justify"><?php echo e($informasi->subjudul); ?>.</p>
                          <p class="card-text">
                            <small>
                                <span class="text-primary " style="margin-right:15px"><i class="fa fa-user  " style="margin-right:5px"> </i>Oleh. <?php echo e(getusername($informasi->user_id)); ?></span> 
                                <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($informasi->created_at))); ?></span>
                                <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($informasi->view); ?></span>
                          
                            </small>
                        </p>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div>   
 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               
            <div class="col-md-12">
                <div class="card mb-3 " style="margin-bottom:10px;border-bottom:1px solid rgb(214, 211, 211);" >
                    <div class="row no-gutters">
                      <div class="col-md-4">
                        <a href="<?php echo e(route('detailalbum',$album->slug)); ?>">
                        <img src="<?php echo e(url(Storage::url($album->getfoto()))); ?>" class="card-img" width="100%" alt="...">
                      </a>
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                            <small>Album Foto:</small>
                            <a href="<?php echo e(route('detailalbum',$album->slug)); ?>">
                                <h4 class="card-title"><strong><?php echo e($album->judul); ?></strong></h4>
                            </a>
                         
                          <p class="card-text">
                            <small>
                  
                                <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($album->tgl))); ?></span>
                                <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($album->view); ?></span>
                          
                            </small>
                        </p>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div>   
 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
               <div class="col-md-6">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               
            <div class="col-md-12">
                <div class="card mb-3 " style="margin-bottom:10px;border-bottom:1px solid rgb(214, 211, 211);" >
                    <div class="row no-gutters">
                      <div class="col-md-4">
                        <a href="<?php echo e(route('detailblog',$blog->slug)); ?>">
                        <img src="<?php echo e(url(Storage::url($blog->cover))); ?>" class="card-img" width="100%" alt="...">
                      </a>
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                            <a href="<?php echo e(route('detailblog',$blog->slug)); ?>">
                                <h4 class="card-title"><strong><?php echo e($blog->judul); ?></strong></h4>
                            </a>
                          <p class="card-text text-justify"><?php echo e($blog->subjudul); ?>.</p>
                          <p class="card-text">
                            <small>
                                <span class="text-primary " style="margin-right:15px"><i class="fa fa-user  " style="margin-right:5px"> </i>Oleh. <?php echo e(getusername($blog->user_id)); ?></span> 
                                <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($blog->created_at))); ?></span>
                                <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($blog->view); ?></span>
                          
                            </small>
                        </p>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div>   
 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               
            <div class="col-md-12">
                <div class="card mb-3 " style="margin-bottom:10px;border-bottom:1px solid rgb(214, 211, 211);" >
                    <div class="row no-gutters">
                      <div class="col-md-4">
                        <a href="<?php echo e(route('detailvideo',$video->slug)); ?>">
                        <i class="fab fa-youtube" style="font-size:80px"></i>
                      </a>
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                            <small>Video:</small>
                            <a href="<?php echo e(route('detailvideo',$video->slug)); ?>">
                                <h4 class="card-title"><strong><?php echo e($video->judul); ?></strong></h4>
                            </a>
                         
                          <p class="card-text">
                            <small>
                  
                                <span class="text-success " style="margin-right:15px"><i class="fa fa-calendar " style="margin-right:5px"> </i><?php echo e(date('d F Y', strtotime($video->tgl))); ?></span>
                                <span  class="text-warning " style="margin-right:15px"><i class="fa fa-eye" style="margin-right:5px"></i><?php echo e($video->view); ?></span>
                          
                            </small>
                        </p>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div>   
 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
               
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/pencarian.blade.php ENDPATH**/ ?>