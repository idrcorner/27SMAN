

<?php $__env->startSection('title'); ?>
<?php echo e($album->judul); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2><?php echo e($album->judul); ?></h2>
            <p class="  text-center" style="color:white"><?php echo e(date('d F Y', strtotime($album->tgl))); ?></p>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li><a href="<?php echo e(route('listalbum')); ?>">Daftar Album Foto</a></li>            
             <li class="active"><?php echo e($album->judul); ?></li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="mu-course-content">
 <div class="container" >
 
    <div class="row mx-0" id="">

        <?php if($album->jumlahfoto()==0): ?>
            <em>Tidak ada foto pada album ini.</em>
        <?php endif; ?>

        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-3">
   
          
            <a href="<?php echo e(url(Storage::url($foto->foto))); ?>" data-lightbox="gallery" data-title="Foto <?php echo e($album->judul); ?>">
                <img src="<?php echo e(url(Storage::url($foto->foto))); ?>" alt="Photo <?php echo e($foto->id); ?>" class="img-thumbnail">
            </a>
 

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

            
      
    </div>
 </div>
</div>
<br>
<br>
<br>
<br>
<br>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
    <script>
        $(document).ready(function(){
        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/detailalbum2.blade.php ENDPATH**/ ?>