

<?php $__env->startSection('title'); ?>
<?php echo e($album->judul); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="mu-page-breadcrumb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-page-breadcrumb-area">
            <h2><?php echo e($album->judul); ?></h2>
            <p class="  text-center" style="color:white"><?php echo e(date('d F Y', strtotime($album->tgl))); ?></p>
            <ol class="breadcrumb">
             <li><a href="<?php echo e(route('home')); ?>">Home</a></li>            
             <li><a href="<?php echo e(route('listalbum')); ?>">Daftar Album Foto</a></li>            
             <li class="active"><?php echo e($album->judul); ?></li>
           </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="mu-course-content">
 <div class="container" >
 
    <div class="row mx-0" id="">

        <?php if($album->jumlahfoto()==0): ?>
            <em>Tidak ada foto pada album ini.</em>
        <?php endif; ?>

           <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-3">
   
            <a href="#" data-toggle="modal" data-target="#photoModal<?php echo e($foto->id); ?>">
                <img src="<?php echo e(url(Storage::url($foto->foto))); ?>" alt="Photo <?php echo e($foto->id); ?>" class="img-thumbnail">
            </a>
        
            <!-- Modal -->
            <div class="modal fade" id="photoModal<?php echo e($foto->id); ?>" tabindex="-1" role="dialog" aria-labelledby="photoModal<?php echo e($foto->id); ?>Label" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                       
                        <div class="modal-body">
                            <img src="<?php echo e(url(Storage::url($foto->foto))); ?>" width="100%" alt="Photo <?php echo e($foto->id); ?>" class="img-fluid">
                        </div>
                        
                    </div>
                </div>
            </div>

            </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
      
    </div>
 </div>
</div>
<br>
<br>
<br>
<br>
<br>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const container = document.querySelector('#bootstrap-image-gallery');
window.lightGallery(container, {
    selector: '.lg-item',
    plugins: [
        lgZoom,
        lgThumbnail
    ],
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/front/detailalbum.blade.php ENDPATH**/ ?>