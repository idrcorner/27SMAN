

<?php $__env->startSection('title'); ?>
    <?php echo e($album->judul); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .delete-button {
    position: absolute;
    bottom: 10;
    left: 10;
}

    .img-container {
        position: relative;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="panel-header bg-primary-gradient">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold"><?php echo e($album->judul); ?></h2>
                    <h5 class="text-white op-7 mb-2"><?php echo e($album->deskripsi); ?></h5>
                </div>
                <div class="ml-md-auto py-2 py-md-0">
                    <button class="btn btn-secondary btn-round"  data-toggle="modal" data-target="#imageModalTambah">Tambah Foto</button>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        <div class="row mt--2">
            <div class="col-md-12">
                <div class="card full-height">
                    <div class="card-body">
                       
                                <i class="fas fa-calendar-alt mr-1 text-success" ></i> <?php echo e(date('d F Y', strtotime($album->tgl))); ?>

                                |
                                 <i class="  fas fa-eye text-primary mr-1"></i> <?php echo e($album->view); ?>

                            
                            
                           
                         
                       <br>
                      
                     <br>
                   <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          
                            <div class="col-3 mb-2 position-relative">
                                <div class="delete-button">
                                    <i  onclick="alertdelete('<?php echo e(url(Storage::url($item->foto))); ?>','<?php echo e($item->id); ?>')"
                                        role="button" class="fas fa-trash-alt text-danger cursor-pointer ml-2 mt-1" title="Hapus"></i>
                                </div>
                                <img src="<?php echo e(url(Storage::url($item->foto))); ?>" onclick="prevImg('<?php echo e(url(Storage::url($item->foto))); ?>')" data-toggle="modal" data-target="#imageModal" width="100%">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <em>Tidak ada foto pada album ini. (<?php echo e($album->judul); ?>).</em>
                        <?php endif; ?>
                    </div>
                     <br>
                     <hr>
                     <a class="btn btn-primary" href="<?php echo e(route('album.index')); ?>">Kembali</a>

                    </div>
                </div>
            </div>
           
        </div>
      
    </div>
</div> 

<!-- Blade view file -->
<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
    
            <div class="modal-body">
                <img id="previewImage" src="" style="max-width: 100%;" />
            </div>
            
        </div>
    </div>
</div>
<div class="modal fade" id="imageModalTambah" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
    
            <div class="modal-body">
                <form action="<?php echo e(route('uploadfoto')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex align-items-center">
                        <label for="imageInput" class="me-3">Pilih Foto:</label>
                        <input type="file" class="form-control me-2" id="imageInput" name="images[]" multiple required>
                        <input type="hidden" name="album_id" value="<?php echo e($album->id); ?>">
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </div>
                  
                </form>

             
            </div>
            
        </div>
    </div>
</div>

<form id="deleteform" action="<?php echo e(route('deletefoto')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <input id="idFoto" type="hidden" name="id" value="">
    <input  type="hidden" name="album_id" value="<?php echo e($album->id); ?>">
 
</form>

<?php $__env->stopSection(); ?>
 

<?php $__env->startSection('script'); ?>
   <script>
         function prevImg(img){      
            $('#previewImage').attr('src',img)
         }

         function alertdelete(judul, id) {
        swal({
            title: 'Anda yakin?'
            , text: "Menghapus Foto ini ?"
            , icon: 'warning'
            , buttons: {
                confirm: {
                    text: 'Ya, Hapus'
                    , className: 'btn btn-primary'
                }
                , cancel: {
                    visible: true
                    , className: 'btn btn-danger'
                }
            }
        }).then((result) => {
            if (result) {
                document.getElementById("idFoto").value=id
                document.getElementById("deleteform").submit();  
            } 
        });
    }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sman27\resources\views/admin/album/show.blade.php ENDPATH**/ ?>